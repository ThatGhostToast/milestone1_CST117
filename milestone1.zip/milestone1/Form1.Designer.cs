﻿namespace InventoryProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ohq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LTS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameEdit = new System.Windows.Forms.Button();
            this.idEdit = new System.Windows.Forms.Button();
            this.descEdit = new System.Windows.Forms.Button();
            this.priceEdit = new System.Windows.Forms.Button();
            this.ohqEdit = new System.Windows.Forms.Button();
            this.ltsEdit = new System.Windows.Forms.Button();
            this.newEntry = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Name,
            this.productID,
            this.Description,
            this.Price,
            this.ohq,
            this.LTS});
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(805, 214);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // Name
            // 
            this.Name.HeaderText = "Name";
            this.Name.MinimumWidth = 6;
            this.Name.Name = "Name";
            this.Name.Width = 125;
            // 
            // productID
            // 
            this.productID.HeaderText = "Product ID";
            this.productID.MinimumWidth = 6;
            this.productID.Name = "productID";
            this.productID.Width = 125;
            // 
            // Description
            // 
            this.Description.HeaderText = "Description";
            this.Description.MinimumWidth = 6;
            this.Description.Name = "Description";
            this.Description.Width = 125;
            // 
            // Price
            // 
            this.Price.HeaderText = "Price";
            this.Price.MinimumWidth = 6;
            this.Price.Name = "Price";
            this.Price.Width = 125;
            // 
            // ohq
            // 
            this.ohq.HeaderText = "On Hand Quantity";
            this.ohq.MinimumWidth = 6;
            this.ohq.Name = "ohq";
            this.ohq.Width = 125;
            // 
            // LTS
            // 
            this.LTS.HeaderText = "Last Time Sold";
            this.LTS.MinimumWidth = 6;
            this.LTS.Name = "LTS";
            this.LTS.Width = 125;
            // 
            // nameEdit
            // 
            this.nameEdit.Location = new System.Drawing.Point(89, 231);
            this.nameEdit.Name = "nameEdit";
            this.nameEdit.Size = new System.Drawing.Size(75, 23);
            this.nameEdit.TabIndex = 1;
            this.nameEdit.Text = "Edit";
            this.nameEdit.UseVisualStyleBackColor = true;
            // 
            // idEdit
            // 
            this.idEdit.Location = new System.Drawing.Point(212, 231);
            this.idEdit.Name = "idEdit";
            this.idEdit.Size = new System.Drawing.Size(75, 23);
            this.idEdit.TabIndex = 2;
            this.idEdit.Text = "Edit";
            this.idEdit.UseVisualStyleBackColor = true;
            // 
            // descEdit
            // 
            this.descEdit.Location = new System.Drawing.Point(339, 231);
            this.descEdit.Name = "descEdit";
            this.descEdit.Size = new System.Drawing.Size(75, 23);
            this.descEdit.TabIndex = 3;
            this.descEdit.Text = "Edit";
            this.descEdit.UseVisualStyleBackColor = true;
            // 
            // priceEdit
            // 
            this.priceEdit.Location = new System.Drawing.Point(466, 231);
            this.priceEdit.Name = "priceEdit";
            this.priceEdit.Size = new System.Drawing.Size(75, 23);
            this.priceEdit.TabIndex = 4;
            this.priceEdit.Text = "Edit";
            this.priceEdit.UseVisualStyleBackColor = true;
            // 
            // ohqEdit
            // 
            this.ohqEdit.Location = new System.Drawing.Point(586, 231);
            this.ohqEdit.Name = "ohqEdit";
            this.ohqEdit.Size = new System.Drawing.Size(75, 23);
            this.ohqEdit.TabIndex = 5;
            this.ohqEdit.Text = "Edit";
            this.ohqEdit.UseVisualStyleBackColor = true;
            // 
            // ltsEdit
            // 
            this.ltsEdit.Location = new System.Drawing.Point(710, 231);
            this.ltsEdit.Name = "ltsEdit";
            this.ltsEdit.Size = new System.Drawing.Size(75, 23);
            this.ltsEdit.TabIndex = 6;
            this.ltsEdit.Text = "Edit";
            this.ltsEdit.UseVisualStyleBackColor = true;
            // 
            // newEntry
            // 
            this.newEntry.BackColor = System.Drawing.SystemColors.MenuBar;
            this.newEntry.Location = new System.Drawing.Point(823, 12);
            this.newEntry.Name = "newEntry";
            this.newEntry.Size = new System.Drawing.Size(113, 57);
            this.newEntry.TabIndex = 7;
            this.newEntry.Text = "Add New Entry";
            this.newEntry.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(949, 289);
            this.Controls.Add(this.newEntry);
            this.Controls.Add(this.ltsEdit);
            this.Controls.Add(this.ohqEdit);
            this.Controls.Add(this.priceEdit);
            this.Controls.Add(this.descEdit);
            this.Controls.Add(this.idEdit);
            this.Controls.Add(this.nameEdit);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn productID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn ohq;
        private System.Windows.Forms.DataGridViewTextBoxColumn LTS;
        private System.Windows.Forms.Button nameEdit;
        private System.Windows.Forms.Button idEdit;
        private System.Windows.Forms.Button descEdit;
        private System.Windows.Forms.Button priceEdit;
        private System.Windows.Forms.Button ohqEdit;
        private System.Windows.Forms.Button ltsEdit;
        private System.Windows.Forms.Button newEntry;
    }
}

